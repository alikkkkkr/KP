package com.example.dlboxmobile;

public class Box {
    private String userSender;
    private String valueOfContent;
    private String packageBox;
    private String sizePackage;
    private float price;

    public Box(String userSender, String valueOfContent, String packageBox, String sizePackage, float price) {
        this.userSender = userSender;
        this.valueOfContent = valueOfContent;
        this.packageBox = packageBox;
        this.sizePackage = sizePackage;
        this.price = price;
    }

    public String getUserSender() {
        return userSender;
    }

    public void setUserSender(String userSender) {
        this.userSender = userSender;
    }

    public String getValueOfContent() {
        return valueOfContent;
    }

    public void setValueOfContent(String valueOfContent) {
        this.valueOfContent = valueOfContent;
    }

    public String getPackageBox() {
        return packageBox;
    }

    public void setPackageBox(String packageBox) {
        this.packageBox = packageBox;
    }

    public String getSizePackage() {
        return sizePackage;
    }

    public void setSizePackage(String sizePackage) {
        this.sizePackage = sizePackage;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
