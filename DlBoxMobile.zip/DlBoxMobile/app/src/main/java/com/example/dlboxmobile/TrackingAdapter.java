package com.example.dlboxmobile;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Класс TrackingAdapter отвечает за работу со списком отслеживаний для вывода в RecycleView.
 */
public class TrackingAdapter extends RecyclerView.Adapter<TrackingAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Tracking> list;

    public TrackingAdapter(Context context, ArrayList<Tracking> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public TrackingAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_tracking_card, parent, false);
        return new TrackingAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrackingAdapter.ViewHolder holder, int position) {
        Tracking tracking = list.get(position);
        holder.tv.setText(tracking.getUniqueOrderNum());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOrderDetails(tracking);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView tv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv = itemView.findViewById(R.id.item_tv);
        }
    }

    private void openOrderDetails(Tracking tracking) {
        Intent intent = new Intent(context, TrackingDetailsActivity.class);
        intent.putExtra("tracking", tracking);
        context.startActivity(intent);
    }
}
