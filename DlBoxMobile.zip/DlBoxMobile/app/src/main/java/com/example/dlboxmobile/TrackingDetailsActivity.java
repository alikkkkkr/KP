package com.example.dlboxmobile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Класс TrackingDetailsActivity отвечает за вывод данных отслеживания.
 */
public class TrackingDetailsActivity extends AppCompatActivity {

    TextView trackNum, status, txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking_details);

        trackNum = findViewById(R.id.tvtrackNum);
        status = findViewById(R.id.tvstatus);
        txt = findViewById(R.id.txt);

        // Получение данных из предыдущей активности
        Tracking tracking = (Tracking) getIntent().getSerializableExtra("tracking");
        if (tracking != null) {
            // Отображение информации

            Log.d("TrackingDetailsActivity", "ИНФА: " + tracking.getStatus());


            trackNum.setText(tracking.getUniqueOrderNum());
            if (status.getText().toString().equals("3")){
                status.setText("Доставлен");
            }
            else{
                status.setText("Оформлен");
            }
        }

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> onBackPressed());

        Button changeStatusBtn = findViewById(R.id.btnChangeStatus);
        changeStatusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tracknum = trackNum.getText().toString();
                Tracking tracking1 = new Tracking(tracknum, "Доставлен");
                changestatus(tracking1, v);
//                if (status.getText() == "3"){
//
//                }
//                else{
//                    Toast.makeText(TrackingDetailsActivity.this, "Посылка уже доставлена", Toast.LENGTH_SHORT).show();
//                }

            }
        });

    }

    private void changestatus(Tracking tracking, View view) {
        api userService = ApiClient.getClient().create(api.class);
        Call<Tracking> call = userService.changeStatus(tracking);
        Log.d("TrackingDetailsActivity", "ИНФА ЗАПРОСА: " + tracking.getUniqueOrderNum() + tracking.getStatus());

        call.enqueue(new Callback<Tracking>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<Tracking> call, Response<Tracking> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(TrackingDetailsActivity.this, "Данные " + response.body(), Toast.LENGTH_SHORT).show();

                    Log.d("TrackingDetailsActivity", "ИНФА ТРЕКА: " + response.body());

                } else {
                    switch (response.code()) {
                        case 400:
                            txt.setText("Неверный логин или пароль");
                            txt.setVisibility(View.VISIBLE);
                            break;
                        case 404:
                            txt.setText("Пользователь не найден");
                            txt.setVisibility(View.VISIBLE);
                            break;
                        default:
                            txt.setText("Ошибка авторизации: " + response.code());
                            txt.setVisibility(View.VISIBLE);
                            break;
                    }
                }
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<Tracking> call, Throwable t) { // Ошибка сетевого запроса
                txt.setText("Произошла сетевая ошибка");
                txt.setVisibility(View.VISIBLE);
            }

        });
    }


}