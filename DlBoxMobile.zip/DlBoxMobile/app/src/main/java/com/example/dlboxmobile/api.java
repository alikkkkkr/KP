package com.example.dlboxmobile;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;


/**
 * Интерфейс api для подключения к базе данных.
 */
public interface api {

    @GET("users/")
    Call<ArrayList<MyUser>> getUsersList();

    @POST("login/")
    Call<MyUser> loginUser(@Body MyUser user);

    @POST("trackchange/")
    Call<Tracking> changeStatus (@Body Tracking tracking);

    @GET("order/")
    Call<ArrayList<Order>> getOrderList();

    @GET("tracking/")
    Call<ArrayList<Tracking>> getTrackingList();

}
