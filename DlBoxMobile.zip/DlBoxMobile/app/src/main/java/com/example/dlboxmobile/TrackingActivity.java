package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Класс TrackingActivity отвечает за вывод списка отслеживаний.
 * Он содержит методы для работы с API.
 */
public class TrackingActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    com.example.dlboxmobile.api apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);

        recyclerView = findViewById(R.id.recycle_view);
        apiInterface = ApiClient.getClient().create(api.class);

        Call<ArrayList<Tracking>> getList = apiInterface.getTrackingList();
        getList.enqueue(new Callback<ArrayList<Tracking>>() {
            @Override
            public void onResponse(Call<ArrayList<Tracking>> call, Response<ArrayList<Tracking>> response) {
                if (response.isSuccessful()){
                    recyclerView.setLayoutManager(new LinearLayoutManager(TrackingActivity.this));
                    recyclerView.setHasFixedSize(true);
                    ArrayList<Tracking> list = response.body();
                    TrackingAdapter adapter = new TrackingAdapter(TrackingActivity.this, list);
                    recyclerView.setAdapter(adapter);

                    for (Tracking tracking : list) {
                        Log.d("TrackingActivity", "Номер заказа: " + tracking.getUniqueOrderNum());
                    }
                } else {
                    Toast.makeText(TrackingActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Tracking>> call, Throwable t) {
                Toast.makeText(TrackingActivity.this, "fail", Toast.LENGTH_SHORT).show();
            }
        });

    }
}