package com.example.dlboxmobile;

import java.io.Serializable;

/**
 * Класс MyUser отвечает за модель пользователя.
 * Он содержит переменные, конструктор, getter и setter.
 */
public class MyUser implements Serializable{
    private String login;
    private String password;
    private String user_surname;
    private String user_name;
    private String user_patronymic;
    private String telephoneNumber;
    private String role;

    public MyUser(String login, String password) {
        this.login = login;
        this.password = password;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUser_surname() {
        return user_surname;
    }

    public void setUser_surname(String user_surname) {
        this.user_surname = user_surname;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_patronymic() {
        return user_patronymic;
    }

    public void setUser_patronymic(String user_patronymic) {
        this.user_patronymic = user_patronymic;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public MyUser(String login, String password, String user_surname, String user_name, String user_patronymic, String telephoneNumber, String role) {
        this.login = login;
        this.password = password;
        this.user_surname = user_surname;
        this.user_name = user_name;
        this.user_patronymic = user_patronymic;
        this.telephoneNumber = telephoneNumber;
        this.role = role;
    }
    public MyUser(String login, String password, String user_surname, String user_name, String user_patronymic, String telephoneNumber) {
        this.login = login;
        this.password = password;
        this.user_surname = user_surname;
        this.user_name = user_name;
        this.user_patronymic = user_patronymic;
        this.telephoneNumber = telephoneNumber;
    }

}
