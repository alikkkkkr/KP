package com.example.dlboxmobile;

public class TypeOfDelivery {
    private String name;
    private float deliveryCost;
    private String description;

    public TypeOfDelivery(String name, float deliveryCost, String description) {
        this.name = name;
        this.deliveryCost = deliveryCost;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getDeliveryCost() {
        return deliveryCost;
    }

    public void setDeliveryCost(float deliveryCost) {
        this.deliveryCost = deliveryCost;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
