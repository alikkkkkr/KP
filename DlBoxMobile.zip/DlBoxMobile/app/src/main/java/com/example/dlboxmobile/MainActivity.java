package com.example.dlboxmobile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Класс MainActivity отвечает за авторизацию пользователя в системе.
 * Он содержит методы для отправки запроса на авторизацию пользователя и обработки ответа от сервера.
 */
public class MainActivity extends AppCompatActivity {

    TextView txt;
    Button loginButton;
    EditText loginInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.txt);

        loginInput = findViewById(R.id.login_input);
        passwordInput = findViewById(R.id.password_input);

        loginButton = findViewById(R.id.btn_login);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = loginInput.getText().toString();
                String password = passwordInput.getText().toString();
                MyUser user = new MyUser(login, password);
                loginUser(user, v);
            }
        });

    }

    private void loginUser(MyUser user, View view) {
        api userService = ApiClient.getClient().create(api.class);
        Call<MyUser> call = userService.loginUser(user);
        call.enqueue(new Callback<MyUser>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<MyUser> call, Response<MyUser> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Данные " + response.body(), Toast.LENGTH_SHORT).show();

                    // Сохранение данных пользователя
                    UserSaveInfo userSaveInfo = new UserSaveInfo(MainActivity.this);
                    MyUser user = response.body();
                    userSaveInfo.saveUserInfo(user);

                    Log.d("MainActivity", "пользователя: " + userSaveInfo.getUserInfo().getLogin());


                    startActivity(new Intent(MainActivity.this, HomeActivity.class));
                } else { // Авторизация не удалась
                    switch (response.code()) {
                        case 400:
                            txt.setText("Неверный логин или пароль");
                            txt.setVisibility(View.VISIBLE);
                            break;
                        case 404:
                            txt.setText("Пользователь не найден");
                            txt.setVisibility(View.VISIBLE);
                            break;
                        default:
                            txt.setText("Ошибка авторизации: " + response.code());
                            txt.setVisibility(View.VISIBLE);
                            break;
                    }
                }
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<MyUser> call, Throwable t) {
                txt.setText("Произошла сетевая ошибка");
                txt.setVisibility(View.VISIBLE);
            }

        });
    }
}