package com.example.dlboxmobile;

public class UserOrders {
    private String user;
    private int order;

    public UserOrders(String user, int order) {
        this.user = user;
        this.order = order;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
}
