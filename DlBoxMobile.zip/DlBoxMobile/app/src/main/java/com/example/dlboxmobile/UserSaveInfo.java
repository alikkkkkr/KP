package com.example.dlboxmobile;

import android.content.Context;
import android.content.SharedPreferences;

public class UserSaveInfo {
    private final SharedPreferences sharedPreferences;

    public UserSaveInfo(Context context) {
        sharedPreferences = context.getSharedPreferences("UserData", Context.MODE_PRIVATE);
    }

    public void saveUserInfo(MyUser user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("login", user.getLogin());
        editor.putString("password", user.getPassword());
        editor.putString("name", user.getUser_name());
        editor.putString("sername", user.getUser_surname());
        editor.putString("patronymic", user.getUser_patronymic());
        editor.putString("telephoneNumber", user.getTelephoneNumber());
        editor.apply();
    }

    public MyUser getUserInfo() {
        String login = sharedPreferences.getString("login", null);
        String hash_password = sharedPreferences.getString("password", null);
        String name = sharedPreferences.getString("name", null);
        String sername = sharedPreferences.getString("sername", null);
        String patronymic = sharedPreferences.getString("patronymic", null);
        String telephoneNumber = sharedPreferences.getString("telephoneNumber", null);

        return new MyUser(login, hash_password, name, sername, patronymic, telephoneNumber);
    }
}
