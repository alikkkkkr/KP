package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

/**
 * Класс OrderDetailsActivity отвечает за вывод данных заказа.
 */
public class OrderDetailsActivity extends AppCompatActivity {

    TextView trackNum, cost, pay, sender, recipient;
    CheckBox doortodoor, postmat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        trackNum = findViewById(R.id.tvtrackNum);
        cost = findViewById(R.id.tvcost);
        pay = findViewById(R.id.tvPayType);
        sender = findViewById(R.id.tvadSender);
        recipient = findViewById(R.id.tvadRecipient);
        doortodoor = findViewById(R.id.tvdoorToDoor);
        postmat = findViewById(R.id.tvpostmat);

        // Получение данных из предыдущей активности
        Order order = (Order) getIntent().getSerializableExtra("order");
        if (order != null) {
            // Отображение информации
            trackNum.setText(order.getUniqueOrderNum());
            cost.setText(String.valueOf(order.getCost()));
            if (pay.getText().toString().equals("2")){
                pay.setText("Картой при получении");
            }
            else{
                pay.setText("Наличными при получении");
            }
            sender.setText(order.getSender_address());
            recipient.setText(order.getRecipient_address());
            doortodoor.setChecked(order.isDoorTodoor());
            postmat.setChecked(order.isPostmat());
        }

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> onBackPressed());

    }
}