package com.example.dlboxmobile;

import java.io.Serializable;

/**
 * Класс Order отвечает за модель заказа.
 * Он содержит переменные, конструктор, getter и setter.
 */
public class Order implements Serializable {
    private String uniqueOrderNum;
    private String box;
    private String delivery;
    private boolean doorTodoor;
    private boolean delicate;
    private float cost;
    private String pay;
    private String timeAdd;
    private String sender_address;
    private String recipient_address;
    private boolean postmat;

    public Order(String uniqueOrderNum, String box, String delivery, boolean doorTodoor, boolean delicate, float cost, String pay, String timeAdd, String sender_address, String recipient_address, boolean postmat) {
        this.uniqueOrderNum = uniqueOrderNum;
        this.box = box;
        this.delivery = delivery;
        this.doorTodoor = doorTodoor;
        this.delicate = delicate;
        this.cost = cost;
        this.pay = pay;
        this.timeAdd = timeAdd;
        this.sender_address = sender_address;
        this.recipient_address = recipient_address;
        this.postmat = postmat;
    }

    public String getUniqueOrderNum() {
        return uniqueOrderNum;
    }

    public void setUniqueOrderNum(String uniqueOrderNum) {
        this.uniqueOrderNum = uniqueOrderNum;
    }

    public String getBox() {
        return box;
    }

    public void setBox(String box) {
        this.box = box;
    }

    public String getDelivery() {
        return delivery;
    }

    public void setDelivery(String delivery) {
        this.delivery = delivery;
    }

    public boolean isDoorTodoor() {
        return doorTodoor;
    }

    public void setDoorTodoor(boolean doorTodoor) {
        this.doorTodoor = doorTodoor;
    }

    public boolean isDelicate() {
        return delicate;
    }

    public void setDelicate(boolean delicate) {
        this.delicate = delicate;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }

    public String getTimeAdd() {
        return timeAdd;
    }

    public void setTimeAdd(String timeAdd) {
        this.timeAdd = timeAdd;
    }

    public String getSender_address() {
        return sender_address;
    }

    public void setSender_address(String sender_address) {
        this.sender_address = sender_address;
    }

    public String getRecipient_address() {
        return recipient_address;
    }

    public void setRecipient_address(String recipient_address) {
        this.recipient_address = recipient_address;
    }

    public boolean isPostmat() {
        return postmat;
    }

    public void setPostmat(boolean postmat) {
        this.postmat = postmat;
    }
}
