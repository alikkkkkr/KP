package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Класс UserDetailsActivity отвечает за вывод данных пользователя.
 */
public class UserDetailsActivity extends AppCompatActivity {

    TextView tvLogin, tvUserSurname, tvUserName, tvUserPatronymic, tvTelephoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        tvLogin = findViewById(R.id.tvLogin);
        tvUserSurname = findViewById(R.id.tvUserSurname);
        tvUserName = findViewById(R.id.tvUserName);
        tvUserPatronymic = findViewById(R.id.tvUserPatronymic);
        tvTelephoneNumber = findViewById(R.id.tvTelephoneNumber);

        // Получение данных о пользователе из предыдущей активности
        MyUser user = (MyUser) getIntent().getSerializableExtra("user");
        if (user != null) {
            // Отображение информации о пользователе
            tvLogin.setText(user.getLogin());
            tvUserSurname.setText(user.getUser_surname());
            tvUserName.setText(user.getUser_name());
            tvUserPatronymic.setText(user.getUser_patronymic());
            tvTelephoneNumber.setText(user.getTelephoneNumber());
        }

//        Оптимизация
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> onBackPressed());
    }
}