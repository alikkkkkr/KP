package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Класс UsersActivity отвечает за вывод списка пользователей.
 * Он содержит методы для работы с API.
 */
public class UsersActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    com.example.dlboxmobile.api apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        recyclerView = findViewById(R.id.recycle_view);
        apiInterface = ApiClient.getClient().create(api.class);

        Call<ArrayList<MyUser>> getList = apiInterface.getUsersList();
        getList.enqueue(new Callback<ArrayList<MyUser>>() {
            @Override
            public void onResponse(Call<ArrayList<MyUser>> call, Response<ArrayList<MyUser>> response) {
                if (response.isSuccessful()){
                    recyclerView.setLayoutManager(new LinearLayoutManager(UsersActivity.this));
                    recyclerView.setHasFixedSize(true);
                    ArrayList<MyUser> list = response.body();
                    ItemAdapter adapter = new ItemAdapter(UsersActivity.this, list);
                    recyclerView.setAdapter(adapter);

                    assert list != null;
                    for (MyUser user : list) {
//                        имена пользователей null, когда login имеет данные
                        Log.d("UsersActivity", "Имя пользователя: " + user.getUser_name());
                    }

                }
                else {
                    Toast.makeText(UsersActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }


            @Override
            public void onFailure(Call<ArrayList<MyUser>> call, Throwable t) {
                Toast.makeText(UsersActivity.this, "", Toast.LENGTH_SHORT).show();
            }
        });

    }
}