package com.example.dlboxmobile;

import java.io.Serializable;

/**
 * Класс Tracking отвечает за модель отслеживания.
 * Он содержит переменные, конструктор, getter и setter.
 */
public class Tracking implements Serializable {
    private String uniqueOrderNum;
    private String status;

    public Tracking(String uniqueOrderNum, String status) {
        this.uniqueOrderNum = uniqueOrderNum;
        this.status = status;
    }

    public String getUniqueOrderNum() {
        return uniqueOrderNum;
    }

    public void setUniqueOrderNum(String uniqueOrderNum) {
        this.uniqueOrderNum = uniqueOrderNum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
