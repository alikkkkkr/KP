package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Класс AccountActivity отвечает за отображение авторизованного данных пользователя.
 * Он содержит методы для вывода данных.
 */
public class AccountActivity extends AppCompatActivity {

    TextView login, name, surname, patronymic, telephone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        login = findViewById(R.id.tvLogin);
        name = findViewById(R.id.tvUserName);
        surname = findViewById(R.id.tvUserSurname);
        patronymic = findViewById(R.id.tvUserPatronymic);
        telephone = findViewById(R.id.tvTelephoneNumber);

        UserSaveInfo userSaveInfo = new UserSaveInfo(AccountActivity.this);
        MyUser user = userSaveInfo.getUserInfo();


        if (user != null) {
            // Отображение информации о пользователе
            login.setText(user.getLogin());
            surname.setText(user.getUser_surname());
            name.setText(user.getUser_name());
            patronymic.setText(user.getUser_patronymic());
            telephone.setText(user.getTelephoneNumber());
        }

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> onBackPressed());
    }
}