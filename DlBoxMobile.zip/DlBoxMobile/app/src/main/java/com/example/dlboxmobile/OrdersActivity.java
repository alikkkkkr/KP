package com.example.dlboxmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Класс OrdersActivity отвечает за вывод списка заказов.
 * Он содержит методы для работы с API.
 */
public class OrdersActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    com.example.dlboxmobile.api apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        Log.d("OrdersActivity", "в классе");


        recyclerView = findViewById(R.id.recycle_view);
        apiInterface = ApiClient.getClient().create(api.class);

        Call<ArrayList<Order>> getList = apiInterface.getOrderList();

        Log.d("OrdersActivity", getList.toString());

        getList.enqueue(new Callback<ArrayList<Order>>() {
            @Override
            public void onResponse(Call<ArrayList<Order>> call, Response<ArrayList<Order>> response) {
                if (response.isSuccessful()){
                    Log.d("OrdersActivity", "в респонсе");

                    recyclerView.setLayoutManager(new LinearLayoutManager(OrdersActivity.this));
                    recyclerView.setHasFixedSize(true);
                    ArrayList<Order> list = response.body();
                    OrderAdapter adapter = new OrderAdapter(OrdersActivity.this, list);
                    recyclerView.setAdapter(adapter);

                    for (Order order : list) {
                        Log.d("HomeActivity", "Номер заказа: " + order.getUniqueOrderNum());
                    }
                } else {
                    Toast.makeText(OrdersActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Order>> call, Throwable t) {
                Toast.makeText(OrdersActivity.this, "fail", Toast.LENGTH_SHORT).show();
            }
        });


    }
}